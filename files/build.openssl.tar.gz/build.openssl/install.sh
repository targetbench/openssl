build_openssl() {
    set -e
    ARCH=`uname -i`
    SrcPath=$(cd `dirname $0`; pwd)
    myOBJPATH=/usr/bin
    BuildPATH="/tmp/openssl"
    mkdir -p $BuildPATH
    TOP_SRCDIR="$SrcPath"
    cp -rf $TOP_SRCDIR/* $BuildPATH
    cd $BuildPATH
    make -s
}

build_openssl
